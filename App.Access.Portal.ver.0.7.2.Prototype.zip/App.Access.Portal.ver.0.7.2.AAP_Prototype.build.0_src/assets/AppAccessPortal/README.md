# App Access Portal (AAP)

The app says what it is about to do. Meet AAP, the ultimate sandbox!
AAP is a non-profit and Freedomful html aimed at being a sandbox. This can also be used basically as an alternative to every emulator you've seen:

### Nox Emulator
Problems:
- Requires a PC!!!!
- Costs CPU
- Needs specific versions

### VMOS Pro
Problems:
- barely emulates all android versions (android 5 - android 7 or your version of android) showing the developer just could not get proper RAM and ROM.
- No .xapk support
- Can only run certain games
- No Built in app cloner

VMOS still has the same problems.

### Cloud emulators:
Problems:
- A big waste of money(Off topic: Wastes money for real life neccesitys.)
- Costs money
- You have practically 70% Control of the VM
- Is glazed too much(Example: Need a phone? Grab _Ugphone_ and *Get* a VM)

### Limbo PC emulator:
Problems:
- Device RAM and specs = Your experience
- Costs a huge .iso to run a simple OS
- Glazed alot with linux.

### But AAP:
Takes zero money for everything
No RAM neccesary
Only internet needed if online or importing an app.
Just needs any app file.
No profit
Costs round about ~1 MB
Not average!
**YOU CAN RUN MORE THAN 1 OS!!!!!**

RUNNING TUTORIAL IS IN THE WIKI.

Requirements:
- Atleast a device
- 1 MB free
- Web browser/HTML runner
- Atleast **ONE** game file(.apk, .xapk, .aab, .apkb, **.exe**)
