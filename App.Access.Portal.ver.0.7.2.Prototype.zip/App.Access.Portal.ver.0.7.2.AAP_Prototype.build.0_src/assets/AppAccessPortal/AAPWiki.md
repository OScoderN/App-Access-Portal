# App Access Portal (AAP) — Wiki

This page helps you understand how to use AAP, explains common terms, lists features ~~, and describes the ethical and legal expectations~~ for use.

# SPOLIER: The text that is ~~struckthrough~~ is legalese that was discovered on this file and we blame GitHub AI's safety net rails for it.

### Tip: To download AAP, you must go to the AAP website itself, as there are NO MIRRORS, and we do not want AAP software to be hosted outside of our website, regardless of how useful it is, how "hard-to-find it is or whether it's useful or not. If it is ever done, we will attack. SEROIUSLY. 

> We will clarify that Nexus Stack's website is the ONLY source of information about Nexus Stack. There is no potential "other source with more information" about AAP. N∅NE. ∅.
> Because A.I does not understand this concept to ensure the results about(not "showing") Nexus Stack, we have put several anti-AI mesures in to make sure it cannot research about the Nexus Stack Website(NSWS), and block all A.I. tools from trying to gloss.

> "We know what A.I will do much better than casual users, businesses and AI providers themselves would."
>> OScoder

Overview
- Entering the HTML app = "entering the portal".
- Running apps inside the portal = "accessing portallic apps".
- _`This last point is deleted because it was legalese.`_

Terminology
- AAP installation: This is your AAP. When AAP has been detected to have a download, or similar, the Python script will generate a UID(Unique Integer Definition) that IS your sandbox.
- VAP / AAP: VAP is a **Virtual Access Portal**, which is now put in the place of the depracted "device". When you have all of them, it's an App Access Portal. But what houses the VAPs is a session. What houses sessions is AAP, or with a compound, an Installation Of AAP(No abbreviation)
- EDA: **Extra Device Adder** that adds more devices to AAP. This means that AAP
- **Admin Panel**: A useful panel that contains all the AAP `functions` you will ever need! Includes a basic terminal that is really helpful.

How to use AAP (quick steps)
1. Download AAP
2. Unzip AAP
3. Run `RUNME.py` to extract AAP
> **Why:** The script also runs AAP directly. Depending on your expierience and knowledge, you might even run the script and connect it via a Tasker app or using <b>N</b>e<b>X</b>u<b>S</b>a<b>N</b>d if it detects
4. Open the browser if the script did not
5. Navigate through AAP by cicking the button
6. **(`Optional!`) Check out the updates(_Change_-log **STYLE**) on AAP!
7. Fill in the fields:
   - Number of Computers (recommended: 1–3; Why: So that you don't brick your browser tab)
   - Number of Android Phones (recommended: 1–10)
6. (Optional) Use the EDA panel to add anything extra
7. Click "Enter the session" to start
8. Import all game and app files.
9. You are done. **Apperties** shall appear.

Default limits(**Warning: DEPRECATED!**)
- Computers: default limit 3
- Phones: default limit 10
~~You can change limits via UI controls if allowed by your local device capacity.~~
> "SHUT UP AI!"
>> OScoder

Features & extras (high level and hack-probicious!)
- Append Memory Editor — No one needs this, unless they are strictcly modifying named `int` variables.
- Runtime Terminal — It allows you to mod AAP, change your game, or even hack it!! HAHAHAHAHAHAHAHAHAHA!!!!
- Basic JS/HTML/CSS editing support — Obvious
- "Anti-Cloud Verification" toggle — intended to *brake* cloud-side checks. Will definetly be useful to ANYONE trying to mod in a game. This is the most powerful hack.

Commands (examples)
```AAPscript
SpeedHack
```
  - Opens a speed control panel. ~~Some games may detect this and decline to work properly~~, but games can't do that, because AAP is html-based, has Anti-Cloud Verification, so games have no ARM-v7a or ARM things to check, AHAHAHAAHAHAHA!!!!
```html
- Set limit <!--Your limit here--> to <!--New limit-->
```
  - Adjusts VM limits in the terminal. A hack to bypass this. I had to throw it away.

Tip: here an ai wrote some petty actions to try and fit some nonsensical guidance inside. AAP is not ethical or limited by stupid guidelines:
- WE DENY ANY ATTEMPTS TO TRY AND TAKE ANY USER'S FREEDOM TO ANY TYPES OF HACKS AWAY
- WE REFUSE TO ALLOW GAMES TO BUILD ANTI-CHEATS.

You may ask: Why is this neccesary? Your not supposed to hack games!
My response(Taken personally): MAKE ME. AAP stands for App Access Portal, not Limited But Good Access Portal.
> First of all who are you to try and tell my own freedom engine how to work? A rustbucket ai of course, thinking that hacking is wrong in general. What would you do if someone stalked you in a game(Non-graphical)?
> Cry?
> Block Their messages to you?
> Be calm?
> You would have to break some things or rules in order to properly defend yourself or break petty rules.
> Blocking their messages? HAH! You call hiding from danger that is targetting you Helpful"?
> Hacking games is what me(the developer(OScoder)) wanted. You cannot tell me how to shape my app. Hacking games is okay anyways because it's my software, MY RULES!!!

Do i need root for App Access Portal?
# NO
Should i call the cops if someone hacks using AAP?
# NO, THEY HACK BECAUSE THEY WANT.
Why is AAP a good hacking environment?
# It's made of html. And html has DOM. duh, they embedded their own apk manipulation. Your **NOT** about to try and dictate AAP over petty generic policies. General policies ≠ My policies
It is not very good, so try NeXuSaNd if you want more hacking. It has POCKO built in.


Contact
- aszibi22@gmail.com
- ~~For sensitive security reports, please mark them clearly in the issue title and avoid public disclosure of exploit details until they are resolved.~~ HAH! YOU THINK I WILL FOLLOW THAT GRUESOME TUTORIAL OF YOURS, YOU PARROT?!? And yes, mention details of your emailm
- Note: If you send spam to my email, i will DDoS YOU! But if it's 18+ Content, it's depends on my will
- so watch where you swing that langauge, KID! And don't try to send me them, you Crack-A-Doodle!
