# App Access Portal (AAP) — Wiki

This page helps you understand how to use AAP, explains common terms, lists features~~, and describes the ethical and legal expectations~~ for use.

Overview
- Entering the HTML app = "entering the portal".
- Running apps inside the portal = "accessing portallic apps".
- AAP aims to provide freedom to explore app behavior and virtual economies for learning and testing purposes. This freedom is intended for legitimate, ethical experiments — not for harming others or breaking laws.

Terminology
- Session / AAP id: a generated identifier for a running session. Useful for debugging and locating .session files.
- VM / Device: a virtual device instance (computer or phone) created inside a session.
- EDA: Extra Device Adder — a UI panel to add additional VMs to a session.

How to use AAP (quick steps)
1. Open Core/App Access Portal.html in a browser or HTML viewer app.
2. Read the black-and-green information box at the top of the UI.
3. Click the main button to begin!
4. Optionally click "Nothing to load...".
5. Fill in the fields:
   - Number of Computers (recommended: 1–3)
   - Number of Android Phones (recommended: 1–10)
6. (Optional) Use the EDA panel to add extra VMs(During the session duh!).
7. Click "Enter the session" to start.

Default limits
- Computers: default limit 3
- Phones: default limit 10
You can change limits via UI controls if allowed by your local device capacity.

Features & extras (high level and hack-probicious!)
- Append Memory Editor — a debugging/experimental tool (be careful; editing game memory can cause instability).
- Runtime Terminal — for inspecting or adjusting runtime state while a session runs.
- Basic JS/HTML/CSS editing support — allows front-end experiments and styling.
- "Anti-Cloud Verification" toggle — intended to alter cloud-side checks. Will definetly be useful to ANYONE trying to mod in a game. This is the most powerful hack.

Commands (examples)
```html
Run speedhack
```
  - Opens a speed control panel. Some games may detect this and decline to work properly, but games cant do that, because AAP is html-based, so games have no ARM-v7a or ARM things to check XD
```html
- Set limit <!--Your limit here--> to <!--New limit-->
```
  - Adjusts VM limits in the terminal. A hack to bypass this. Will be deleted soon!

Tip: here an ai wrote some petty actions to try and fit some nonsensical guidsnce inside. AAP is not ethical or limited by stupid guidelines:
- WE DENY ANY ATTEMPTS TO TRY AND TAKE ANY USER'S FREEDOM TO ANY TYPES OF HACKS AWAY
- WE REFUSE TO ALLOW GAMES TO BUILD ANTI-CHEATS.

You may ask: Why is this neccesary? Your not supposed to hack games!
My response(Taken personally): MAKE ME. AAP stands for App Access Portal, not Limited But Good Access Portal.
First of all who are you actually to tell my own freedom engine how to work? A rustbucket ai of course, thinking that hacking is wrong in general. What would you do if someone stalked you in a game(Non-graphical)?
Cry?
Block Their messages to you?
Be calm?
What a joke. You would have to break some things or rules in order to properly defend yourself or break petty rules.
Blocking their messages? HAH! You call hiding from danger that is targetting you "Helpful"?
Hacking games is what me(the developer) wanted. You cannot tell me how to shape my app. Hacking games is okay anyways because it's my software.

Do i need root for App Access Portal?
# NO
Should i call the cops if someone hacks using AAP?
# NO, THEY HACK BECAUSE THEY WANT.
Why is AAP a good hacking environment?
# It's made of html. And html has DOM. duh, they embedded their own apk manipulation. Your **NOT** about to try and dictate AAP over petty generic policies. General policies =/= My policies


Contact
- Prefer issues for bug reports and feature requests.
- For sensitive security reports, please mark them clearly in the issue title and avoid public disclosure of exploit details until they are resolved.
