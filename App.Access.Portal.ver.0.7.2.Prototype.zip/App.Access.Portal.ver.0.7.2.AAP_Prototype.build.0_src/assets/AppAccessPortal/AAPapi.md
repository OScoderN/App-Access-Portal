# The `AAPPI`

The AAPPI(AAI) is the App Access Portal Programing Interface. Remember the API's back then?

```HTTPS
{
  type: POST
  headers: {
    type: Application/JSON
  }
  body: // I CAN'T CODE LIKE THIS!!!!
}
```

Fustrating? Yes. You have to write that ugly HTTPS thing, and have to feel heartbroken when you ned JSON + HTTPS! That's a spit in the `coder`'s face, especially me, **`OScoder`**(the one who wrote this). Luckily, AAP doesn't require that! This API will teach you how to program AAP in your apperties and use it.

> # Note: THIS REQUIRES AAP ≥ 1.5, as it uses `Applicate`, which, is `AAP Studio`(derived from: `Android Studio`)
> No other version of AAP `< 1.5` works! NOTHING! Check your AAP version with `Lucky Patcher`, or press <button>Description</button> in the menu!

***

# How to use Applicate

To get started, Open AAP(not `ACLAPP`) on your phone. Then, press <button>**S T A R T**</button>.

You will be greeted with a BIOS, or , if you pressed <button>**Quick Access**</button>, you will see a phone and a computer.

***

### For those who see the **`BIOS`**,


Simply put the number <button>1</button> in the field of the device you want to develop an appertie for. Then hit <button>Generate</button>.

***

Applicate is installed by default, only for AAP 1.5.

# How an appertie is made💡

It looks like:
```
Appertie
  LOOK
    Main.html // (could  be more than one)
    cssMain.css
  FUNCTION
    script.js // all scripts!
  metadata.json
```

1. Open the editor
2. Edit the main.html(s):

> Examples
> > Note: This is the correct way to make a *"Hello, NXS!"* page.
> # Example 1: Compact Appertie
> A compact appertie stores all it's content in one `<implement>`. `<implement>` means store css and javascript somewhere.
```
<content>
  <implement>[script.js]</implement>
  <page main=true>
    <p>Hello, NXS!</p>
  </page>
  <page>
    <button>Nice Job!</button>
  </page>
</content>
```
> `<implement>[&]</implement>` means implement &. This tag requires an array of files to implement. This includes the app's scripts, data, and css.
> It helps **house everything together**.

> # Example 2: Seperated appertie
> A seperated apperite has it's pages and implementations seperated. You should use this if you app has 3D engines in it, which AAP will roll out in AAP 1.7 Trimensional.
> Don't fry your brain trying to do this! Stick to Example 1!

When your looks are done, to create an element in `JavaScript`:
`AAPPI.Create("Element");`

AAPPI means "The AAP API". You can use it, but it isn't an element you see.

You can also:
```
for (i = 0; i <= count; i++) {
  AAPPI.Create("Element" + i);
}
```
AAPPI supports `i`. So you'd see in the DOM tree:

```
<element1></element1>
<element2></element2>
<element3></element3>
<element4></element4>
```

See? Easy. But without `document.body.createElement("element" + i);`...
With permissions, they are always required. In the manifest:

```
{
  "Permissions": [
    "Storage"
    { 
      "Appertie": [
        "Download"
        "Install"
        "Uninstall"
        "Internet"
      ]
    }
    "Background" // YES! Apps can run in the background, with permission only
  ]
}
```

