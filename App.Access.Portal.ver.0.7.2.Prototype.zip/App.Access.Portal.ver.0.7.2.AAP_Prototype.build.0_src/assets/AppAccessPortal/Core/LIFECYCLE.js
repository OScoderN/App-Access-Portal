// Tip: To define or make a class, every class has it's own HTML source, so do NOT call `let vari = new screen();`!!!!

function Print(Operator, Text) {
  console.log("[" + Operator + "]: " + Text);
}

class Session extends HTMLElement {
  constructor(ID, RSC, Port, Size) {
    super();
    this.id = ID;
    this.rsc = RSC; // RSC = Remote Session Code.
    this.port = Port; // The DOM container for a session is stored *here*
    this.width = 20px;
    this.height = 40px;
  }
  
  function add(Device) {
      const TarID = Device.id;
      const TarState = Device.state;
      switch(Device.type) {
        case "Phone":
          // logic
        case "Screen":
          // logic
        case 
      }
  }
}

class PhoneOS extends screen {
  constructor(id, State, Size) {
    super();
    this.id = id;
    this.state = Convert(State, toCent);
    this.border = 5px;
    if (this.src == undefined) { // If the Phone is defined without a arc
        try {
            this.src = "../DefaultApperties/DefaultScreen.html";
        } catch (e) {
            Print("FATAL ERROR", "PhoneOS " this.id + " has failed to be defaulted, because of:" + e)
        }
    }
    
  }
  
  function turnOff() {
    this.src = 
  }
}

class screen extends HTMLIframeElement {
    constructor(Content, State, css) {
        super();
        this.content = Content;
        if (state = null) {
            this.state = "on";
        } else {
            this.state = State;
        
        this.css = css;
    }
}

/// This is the official AAP convertation machine that converts values to other similar values.
/// This function, called "Convert()", converts any value to another using an if-based algorithym.
/// To use it, type your input, and then the process(what you want to do to the input), and the value will be converted to another.
/// It does NOT work on objects, devices, or sessions, it's just a compiler.
/// The function is useful for anyone who needs to convert 1 value to another.
function Convert(input, process) {
    let output;
    // if the input is a light switch and we must provide a result for 100
    if (input == "on" || input == "off" && process == "toCent") {
        if (input == "on") {
            output = 100;
            return output;
        }
        if (input == "off") {
            output = 0;
            return output;
        }
    // for 1 and 0 only...
    if (input == "on" || input == "off" && process == "toBinary") {
        if (input = "on") {
            output = 1;
            return output;
        }
        if (input == "off) {
            output = 0;
            return output;
        } else {
            output = null;
            console.log("[Converter]: There is no binary that isn't on or off, so we return " + output + ".");
            return output;
        }
    }
    if (input = 0 || input = 1 && process = "SwitchState") {
        if (input = 1) {
            output = "on";
            return output;
        }
        if (input = 0) {
            output = "off";
            return output;
        }
    }
}