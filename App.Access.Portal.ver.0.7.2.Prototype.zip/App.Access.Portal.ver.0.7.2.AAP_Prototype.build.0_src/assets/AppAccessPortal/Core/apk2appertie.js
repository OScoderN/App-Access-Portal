// === AAP_fullEngine (modified) ===
// Call: const result = await AAP_fullEngine(apkFile);
// Returns: { appertie, id, stored: true }
// Throws on fatal errors.

async function AAP_fullEngine(apkFile, opts = { persist: true }) {
  // Validation
  if (!apkFile || typeof apkFile.arrayBuffer !== 'function') {
    throw new Error('AAP_fullEngine requires a File/Blob object representing an .apk.');
  }

  console.log('[AAP] Starting engine for:', apkFile.name);

  // --- Read APK bytes ---
  let arrayBuffer;
  try {
    arrayBuffer = await apkFile.arrayBuffer();
  } catch (e) {
    throw new Error('Failed to read APK file: ' + (e && e.message ? e.message : String(e)));
  }
  const bytes = new Uint8Array(arrayBuffer);
  const byteLen = bytes.length;
  console.log(`[AAP] APK size: ${byteLen} bytes`);

  // --- Inline helpers (all inside this function) ---
  const le32 = (buf, idx) => (buf[idx] | (buf[idx+1]<<8) | (buf[idx+2]<<16) | (buf[idx+3]<<24)) >>> 0;
  const le16 = (buf, idx) => (buf[idx] | (buf[idx+1]<<8)) >>> 0;
  const sliceU8 = (buf, start, len) => buf.subarray(start, start + len);
  const decodeUtf8 = (u8) => (new TextDecoder('utf-8')).decode(u8);
  const readULEB = (buf, start) => { let result = 0, shift = 0, pos = start, b; do { b = buf[pos++]; result |= (b & 0x7f) << shift; shift += 7; } while ((b & 0x80) !== 0); return { value: result >>> 0, size: pos - start }; };

  // Decompress deflate helper: try 'deflate' then 'deflate-raw'
  const decompressDeflate = async (u8) => {
    if (typeof DecompressionStream !== 'function') {
      throw new Error('DecompressionStream is not available in this runtime. APK deflate decompression impossible.');
    }
    // try zlib-wrapped deflate first ('deflate'), then 'deflate-raw'
    const tryMode = async (mode) => {
      try {
        const ds = new DecompressionStream(mode);
        const stream = new Response(new Blob([u8]).stream().pipeThrough(ds));
        const ab = await stream.arrayBuffer();
        return new Uint8Array(ab);
      } catch (e) {
        // rethrow to let caller try next
        throw e;
      }
    };
    try {
      return await tryMode('deflate'); // most browsers support 'deflate'
    } catch (_) {
      try {
        return await tryMode('deflate-raw');
      } catch (err) {
        throw new Error('Decompression failed for both deflate types: ' + (err && err.message ? err.message : String(err)));
      }
    }
  };

  // IndexedDB helpers (inline, promisified)
  const openIDB = () => new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') return reject(new Error('IndexedDB not available in this environment.'));
    const req = indexedDB.open('AAP_DB_v1', 1);
    req.onupgradeneeded = (ev) => {
      const db = ev.target.result;
      if (!db.objectStoreNames.contains('apperties')) db.createObjectStore('apperties', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('assets')) db.createObjectStore('assets', { keyPath: 'assetKey' });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error('IndexedDB open failed'));
  });

  const idbPut = (db, storeName, value) => new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    const r = store.put(value);
    r.onsuccess = () => resolve(true);
    r.onerror = () => reject(r.error || new Error('IDB put failed'));
  });

  const idbGet = (db, storeName, key) => new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const r = store.get(key);
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error || new Error('IDB get failed'));
  });

  // --- ZIP local-file header scan and entry list ---
  const entries = [];
  let ptr = 0;
  try {
    while (ptr < byteLen - 30) {
      if (bytes[ptr] === 0x50 && bytes[ptr+1] === 0x4b && bytes[ptr+2] === 0x03 && bytes[ptr+3] === 0x04) {
        const localHeaderOffset = ptr;
        ptr += 4;
        const versionNeeded = le16(bytes, ptr); ptr += 2;
        const gpbit = le16(bytes, ptr); ptr += 2;
        const compMethod = le16(bytes, ptr); ptr += 2;
        ptr += 2; ptr += 2; // mod time/date
        const crc32 = le32(bytes, ptr); ptr += 4;
        const compSize = le32(bytes, ptr); ptr += 4;
        const uncompSize = le32(bytes, ptr); ptr += 4;
        const nameLen = le16(bytes, ptr); ptr += 2;
        const extraLen = le16(bytes, ptr); ptr += 2;

        const nameStart = ptr;
        const nameBytes = sliceU8(bytes, nameStart, nameLen);
        const filename = decodeUtf8(nameBytes);
        ptr += nameLen + extraLen;

        const dataOffset = ptr;
        // compressed size may be zero for streamed sizes; trust compSize
        ptr += compSize;

        entries.push({
          name: filename,
          compMethod,
          compSize,
          uncompSize,
          dataOffset,
          compStart: dataOffset,
          compEnd: dataOffset + compSize,
          localHeaderOffset
        });

        continue;
      } else {
        ptr++;
      }
    }
  } catch (e) {
    throw new Error('ZIP scanning failed: ' + (e && e.message ? e.message : String(e)));
  }

  console.log('[AAP] ZIP entries found:', entries.length);

  // Prepare appertie containers
  const appertie = {
    id: `${apkFile.name}::${Date.now()}`,
    meta: {
      apkName: apkFile.name,
      created: Date.now()
    },
    LOOK: {},       // filename -> text string
    Function: {},   // filename -> text string
    RawDEX: {},     // filename -> Uint8Array
    DEXTables: {},  // filename -> parsed tables
    AssetsIndex: {},// filename -> { assetKey, contentType, size } (stored in IDB)
    runtime: { convertQueue: [], convertedCache: {} }
  };

  // --- Extract entries, decode text and prepare asset Blobs ---
  for (let i = 0; i < entries.length; i++) {
    const e = entries[i];
    try {
      let fileBytes;
      if (e.compMethod === 0) {
        fileBytes = sliceU8(bytes, e.compStart, e.compSize);
      } else if (e.compMethod === 8) {
        const comp = sliceU8(bytes, e.compStart, e.compSize);
        fileBytes = await decompressDeflate(comp);
      } else {
        // unsupported compression method — fail fast with explicit message
        throw new Error(`Unsupported compression method ${e.compMethod} for ${e.name}`);
      }

      const lower = e.name.toLowerCase();

      // TEXT-like assets: attempt to decode as UTF-8; binary xml may decode to garbled text but keep for inspection.
      if (lower.endsWith('.xml') || lower.endsWith('.html') || lower.endsWith('.css')) {
        try { appertie.LOOK[e.name] = decodeUtf8(fileBytes); }
        catch (_) { appertie.LOOK[e.name] = decodeUtf8(fileBytes); }
        console.log(`[AAP] LOOK: ${e.name}`);
      } else if (lower.endsWith('.js')) {
        appertie.Function[e.name] = decodeUtf8(fileBytes);
        console.log(`[AAP] FUNCTION: ${e.name}`);
      } else if (lower.endsWith('.dex')) {
        appertie.RawDEX[e.name] = fileBytes; // store raw dex for parsing / conversion
        console.log(`[AAP] DEX: ${e.name} (${fileBytes.length} bytes)`);
      } else {
        // treat as binary asset: create blob, store in IndexedDB later
        // attempt to detect content type from extension (basic)
        let contentType = 'application/octet-stream';
        if (/\.(png|jpg|jpeg|gif|webp|bmp|svg)$/i.test(e.name)) {
          const ext = e.name.split('.').pop().toLowerCase();
          if (ext === 'png') contentType = 'image/png';
          else if (ext === 'jpg' || ext === 'jpeg') contentType = 'image/jpeg';
          else if (ext === 'gif') contentType = 'image/gif';
          else if (ext === 'webp') contentType = 'image/webp';
          else if (ext === 'bmp') contentType = 'image/bmp';
          else if (ext === 'svg') contentType = 'image/svg+xml';
        } else if (/\.(mp3|wav|ogg)$/i.test(e.name)) contentType = 'audio/*';
        else if (/\.(mp4|webm|mkv)$/i.test(e.name)) contentType = 'video/*';

        // store asset info in AssetsIndex; actual Blob saved to IndexedDB later
        const assetKey = `${appertie.id}::asset::${e.name}`;
        appertie.AssetsIndex[e.name] = { assetKey, contentType, size: fileBytes.length };

        // temporarily keep bytes in memory until we open IDB to store them
        appertie.AssetsIndex[e.name]._tmpBytes = fileBytes;

        console.log(`[AAP] ASSET queued: ${e.name} (${fileBytes.length} bytes)`);
      }
    } catch (err) {
      // fail hard with context
      throw new Error(`Failed to extract ${e.name}: ${err && err.message ? err.message : String(err)}`);
    }
  } // end entries loop

  // --- Parse DEX files fully (inline) ---
  for (const dexName of Object.keys(appertie.RawDEX)) {
    try {
      const dv = appertie.RawDEX[dexName];
      const magic = String.fromCharCode(dv[0], dv[1], dv[2], dv[3], dv[4], dv[5], dv[6], dv[7]);
      if (!magic.startsWith('dex\n')) throw new Error('Invalid DEX magic: ' + magic);

      // read header fields
      const header = {
        magic,
        checksum: le32(dv, 8),
        signature: Array.from(dv.subarray(12, 32)),
        file_size: le32(dv, 32),
        header_size: le32(dv, 36),
        endian_tag: le32(dv, 40),
        link_size: le32(dv, 44),
        link_off: le32(dv, 48),
        map_off: le32(dv, 52),
        string_ids_size: le32(dv, 56),
        string_ids_off: le32(dv, 60),
        type_ids_size: le32(dv, 64),
        type_ids_off: le32(dv, 68),
        proto_ids_size: le32(dv, 72),
        proto_ids_off: le32(dv, 76),
        field_ids_size: le32(dv, 80),
        field_ids_off: le32(dv, 84),
        method_ids_size: le32(dv, 88),
        method_ids_off: le32(dv, 92),
        class_defs_size: le32(dv, 96),
        class_defs_off: le32(dv, 100),
        data_size: le32(dv, 104),
        data_off: le32(dv, 108)
      };

      // string_ids -> offsets
      const stringOffsets = [];
      for (let i = 0; i < header.string_ids_size; i++) {
        const off = le32(dv, header.string_ids_off + i*4) >>> 0;
        stringOffsets.push(off);
      }

      // parse strings
      const strings = [];
      for (let i = 0; i < stringOffsets.length; i++) {
        let pos = stringOffsets[i];
        const uleb = readULEB(dv, pos); pos += uleb.size;
        // string bytes until terminator 0x00
        let end = pos;
        while (end < dv.length && dv[end] !== 0) end++;
        const bytesSegment = dv.subarray(pos, end);
        strings.push(decodeUtf8(bytesSegment));
      }

      // type_ids -> map to strings[]
      const typeIds = [];
      for (let i = 0; i < header.type_ids_size; i++) {
        const sidx = le32(dv, header.type_ids_off + i*4);
        typeIds.push(strings[sidx]);
      }

      // proto_ids
      const protoIds = [];
      for (let i = 0; i < header.proto_ids_size; i++) {
        const off = header.proto_ids_off + i*12;
        const shorty_idx = le32(dv, off);
        const return_type_idx = le32(dv, off + 4);
        const parameters_off = le32(dv, off + 8);
        protoIds.push({ shorty: strings[shorty_idx], returnType: typeIds[return_type_idx], paramsOff: parameters_off });
      }

      // field_ids
      const fieldIds = [];
      for (let i = 0; i < header.field_ids_size; i++) {
        const off = header.field_ids_off + i*8;
        const class_idx = le16(dv, off);
        const type_idx = le16(dv, off+2);
        const name_idx = le32(dv, off+4);
        fieldIds.push({ classType: typeIds[class_idx], type: typeIds[type_idx], name: strings[name_idx] });
      }

      // method_ids
      const methodIds = [];
      for (let i = 0; i < header.method_ids_size; i++) {
        const off = header.method_ids_off + i*8;
        const class_idx = le16(dv, off);
        const proto_idx = le16(dv, off+2);
        const name_idx = le32(dv, off+4);
        methodIds.push({ classType: typeIds[class_idx], proto: protoIds[proto_idx], name: strings[name_idx] });
      }

      // class_defs
      const classDefs = [];
      for (let i = 0; i < header.class_defs_size; i++) {
        const off = header.class_defs_off + i*32;
        const class_idx = le32(dv, off);
        const access_flags = le32(dv, off+4);
        const superclass_idx = le32(dv, off+8);
        const interfaces_off = le32(dv, off+12);
        const source_file_idx = le32(dv, off+16);
        const annotations_off = le32(dv, off+20);
        const class_data_off = le32(dv, off+24);
        const static_values_off = le32(dv, off+28);
        classDefs.push({
          classType: typeIds[class_idx],
          access_flags,
          superclass: superclass_idx >= 0 ? typeIds[superclass_idx] : null,
          interfaces_off,
          source_file: source_file_idx >= 0 ? strings[source_file_idx] : null,
          class_data_off,
          static_values_off
        });
      }

      // class_data parsing -> encoded fields & methods
      const classData = [];
      for (let ci = 0; ci < classDefs.length; ci++) {
        const c = classDefs[ci];
        if (!c.class_data_off) { classData.push(null); continue; }
        let pos = c.class_data_off;
        const ssz = readULEB(dv, pos); pos += ssz.size;
        const insz = readULEB(dv, pos); pos += insz.size;
        const dsz = readULEB(dv, pos); pos += dsz.size;
        const vsz = readULEB(dv, pos); pos += vsz.size;
        const decodeField = () => { const a = readULEB(dv, pos); pos += a.size; const b = readULEB(dv, pos); pos += b.size; return { field_idx_diff: a.value, access_flags: b.value }; };
        const staticFields = []; for (let s=0;s<ssz.value;s++) staticFields.push(decodeField());
        const instanceFields = []; for (let s=0;s<insz.value;s++) instanceFields.push(decodeField());
        const decodeMethod = () => { const a = readULEB(dv, pos); pos += a.size; const b = readULEB(dv, pos); pos += b.size; const cff = readULEB(dv, pos); pos += cff.size; return { method_idx_diff: a.value, access_flags: b.value, code_off: cff.value }; };
        const directMethods=[]; for (let d=0; d<dsz.value; d++) directMethods.push(decodeMethod());
        const virtualMethods=[]; for (let v=0; v<vsz.value; v++) virtualMethods.push(decodeMethod());
        classData.push({ staticFields, instanceFields, directMethods, virtualMethods });
      }

      // reconstruct methods table (absolute indexes) and read code_item locations
      const methodsTable = [];
      for (let ci = 0; ci < classDefs.length; ci++) {
        const cd = classData[ci]; if (!cd) continue;
        let last = 0;
        for (let m = 0; m < cd.directMethods.length; m++) {
          last += cd.directMethods[m].method_idx_diff;
          const methodId = methodIds[last];
          const codeOff = cd.directMethods[m].code_off;
          let codeItem = null;
          if (codeOff) {
            const roff = codeOff;
            const registers_size = le16(dv, roff);
            const ins_size = le16(dv, roff+2);
            const outs_size = le16(dv, roff+4);
            const tries_size = le16(dv, roff+6);
            const debug_off = le32(dv, roff+8);
            const insns_size = le32(dv, roff+12);
            const insnsStart = roff + 16;
            const insns = dv.subarray(insnsStart, insnsStart + insns_size * 2);
            codeItem = { registers_size, ins_size, outs_size, tries_size, debug_off, insns_size, insns, codeOff };
          }
          methodsTable.push({ class: classDefs[ci].classType, methodId, codeItem, kind: 'direct' });
        }
        last = 0;
        for (let m = 0; m < cd.virtualMethods.length; m++) {
          last += cd.virtualMethods[m].method_idx_diff;
          const methodId = methodIds[last];
          const codeOff = cd.virtualMethods[m].code_off;
          let codeItem = null;
          if (codeOff) {
            const roff = codeOff;
            const registers_size = le16(dv, roff);
            const ins_size = le16(dv, roff+2);
            const outs_size = le16(dv, roff+4);
            const tries_size = le16(dv, roff+6);
            const debug_off = le32(dv, roff+8);
            const insns_size = le32(dv, roff+12);
            const insnsStart = roff + 16;
            const insns = dv.subarray(insnsStart, insnsStart + insns_size * 2);
            codeItem = { registers_size, ins_size, outs_size, tries_size, debug_off, insns_size, insns, codeOff };
          }
          methodsTable.push({ class: classDefs[ci].classType, methodId, codeItem, kind: 'virtual' });
        }
      }

      appertie.DEXTables[dexName] = { header, strings, typeIds, protoIds, fieldIds, methodIds, classDefs, classData, methodsTable };
      console.log(`[AAP] Parsed DEX ${dexName} (strings=${strings.length}, methods=${methodsTable.length})`);
    } catch (err) {
      throw new Error(`DEX parse failed for ${dexName}: ${err && err.message ? err.message : String(err)}`);
    }
  } // end dex parse loop

  // --- Persist assets and appertie metadata to IndexedDB (if requested) ---
  if (opts.persist) {
    let db;
    try { db = await openIDB(); }
    catch (e) { throw new Error('Failed to open IndexedDB: ' + (e && e.message ? e.message : String(e))); }

    // Save binary assets: iterate AssetsIndex, convert _tmpBytes -> Blob and store
    const assetEntries = Object.entries(appertie.AssetsIndex || {});
    for (let [filename, info] of assetEntries) {
      try {
        const bytesArr = info._tmpBytes;
        if (!bytesArr) continue; // already stored or empty
        const blob = new Blob([bytesArr], { type: info.contentType || 'application/octet-stream' });
        const putObj = { assetKey: info.assetKey, filename, blob, contentType: info.contentType, size: info.size, created: Date.now() };
        await idbPut(db, 'assets', putObj);
        // remove tmp bytes to free memory
        delete info._tmpBytes;
        console.log(`[AAP] Asset stored: ${filename} -> ${info.assetKey}`);
      } catch (err) {
        throw new Error(`Failed storing asset ${filename}: ${err && err.message ? err.message : String(err)}`);
      }
    }

    // Prepare metadata object for apperties store: omit heavy binary bytes
    const metaToStore = {
      id: appertie.id,
      meta: appertie.meta,
      LOOK: Object.keys(appertie.LOOK),
      Function: Object.keys(appertie.Function),
      RawDEX: Object.keys(appertie.RawDEX),
      AssetsIndex: Object.fromEntries(Object.entries(appertie.AssetsIndex).map(([k, v]) => [k, { assetKey: v.assetKey, contentType: v.contentType, size: v.size }])),
      created: Date.now()
    };

    try {
      await idbPut(db, 'apperties', metaToStore);
      console.log(`[AAP] Appertie metadata saved to IndexedDB (id=${appertie.id})`);
    } catch (err) {
      throw new Error('Failed saving appertie metadata: ' + (err && err.message ? err.message : String(err)));
    }
  } // end persist

  console.log('[AAP] Engine finished successfully.');
  return { appertie, id: appertie.id, stored: !!opts.persist };
} // end AAP_fullEngine

// TriggerApk: single-call function to convert an APK into an Appertie, save assets, and load it
async function TriggerApk(apkFile) {
    if (!apkFile) {
        console.error("[AAP ERROR]: No APK file provided to TriggerApk!");
        return;
    }

    try {
        // Step 1: Run the big engine to convert APK into Appertie (HTML/CSS/JS + Assets)
        const appertieData = await AAP_fullEngine(apkFile); // assumes this returns full folder structure

        if (!appertieData) {
            console.error("[AAP ERROR]: Engine failed to convert APK.");
            return;
        }

        // Step 2: Save the Appertie locally so refresh won't break it
        const appertieID = appertieData.name || `Appertie_${Date.now()}`;
        saveAppertieLocally(appertieID, appertieData);

        // Step 3: Inject LOOK files (HTML + CSS)


        // Step 4: Inject JS files
        if (appertieData.Function) {
            Object.values(appertieData.Function).forEach(jsCode => {
                const scriptTag = document.createElement("script");
                scriptTag.textContent = jsCode;
                document.body.appendChild(scriptTag);
            });
        }

        // Step 5: Inject Assets (images, audio, etc.)
        if (appertieData.Assets) {
            Object.entries(appertieData.Assets).forEach(([filename, dataUrl]) => {
                // Automatically create image elements for PNG/JPG
                if (/\.(png|jpg|jpeg|gif|svg)$/i.test(filename)) {
                    const img = document.createElement("img");
                    img.src = dataUrl;
                    img.alt = filename;
                    document.body.appendChild(img);
                }
                // Additional asset handling can be added here (audio/video)
            });
        }

        console.log(`[AAP]: APK '${apkFile.name}' successfully converted and loaded as Appertie '${appertieID}'!`);
    } catch (e) {
        console.error("[AAP ERROR]: TriggerApk failed.", e);
    }
}