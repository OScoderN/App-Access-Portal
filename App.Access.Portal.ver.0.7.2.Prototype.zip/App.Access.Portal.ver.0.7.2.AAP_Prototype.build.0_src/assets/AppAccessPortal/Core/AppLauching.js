// Hello, if you are exploring system files, here's a warning: Please stop. You might end up editing a very important file by mistake!
// This script helps with some launching of files. Every file has a look folder and the files outside Look And Function help form the look of an app on the home screen.
// Maybe hackers are reading this? Anyways...
console.log("If nothing shows IDK what happens for you :/")
// Function to open an app and run it's Look and Function
async function LaunchAppertie(AppertieID, SysorInt, DeviceType) {
    const TargetAppertie = document.getElementById(AppertieID);

    // --- 1: Load LOOK files (.css, .html) ---
    for (const ext of ['.css', '.html']) {
        const files = await fetchFilesFromPath(SysOrInt + "Apperties/${SysorInt}/${AppertieID}/LOOK", ext);
        files.forEach(f => loadFile(f, TargetAppertie));
    }
    console.log(`[RUNNER]: Loaded the ${AppertieID} appertie's looks!`);

    // --- 2: Load FUNCTION files (.js) ---
    for (const ext of ['.js']) {
        const files = await fetchFilesFromPath(`${DeviceType} Apperties/${SysorInt}/${AppertieID}/Function`, ext);
        files.forEach(f => loadFile(f, TargetAppertie));
    }
    console.log("[RUNNER]: Loaded the" + AppertieID + "functions!");

    // --- 3: Launch starting APK activity ---
    try {
        const manifestRes = await fetch(`${DeviceType} Apperties/${SysorInt}/${AppertieID}/manifest.json`);
        const manifest = await manifestRes.json();

        const startActivity = manifest.StartingActivity;
        if (startActivity && typeof window[startActivity] === 'function') {
            console.log(`[RUNNER]: Launching starting activity: ${startActivity}`);
            window[startActivity](); 
        } else {
            console.warn(`[RUNNER]: Starting activity not found, skipping APK launch.`);
        }
    } catch (e) {
        console.warn(`[RUNNER]: No manifest found or invalid JSON, skipping APK activity launch.`);
    }

let AAPBGPermissions = {
    "DRAW_OVERLAY_PERMISSION": "revoked",
    "READ_STORAGE_PERMISSION": "revoked",
    "WRITE_STORAGE_PERMISSION": "revoked",
    "ACCESSIBILITY_SERVICE": "revoked",
}


function LaunchBackgroundService(BackgroundServiceID, PermissionsNeeded) {
    for (let i = 0; i < AAPBGPermissions.length; i++) {
        GrantPermission(BackgroundServiceID, AAPBGPermissions[i]);
        console.log("Gave " + BackgroundServiceID + " permission to: " + AAPBGPermissions[i] + "!");
    }
}



function GrantPermission(ScriptName, PermissionName) {
    if (!(PermissionName in AAPBGPermissions)) {
        alert("ERROR: Invalid permission name!")
        console.log("Invalid Permission not granted.");
    }
}

