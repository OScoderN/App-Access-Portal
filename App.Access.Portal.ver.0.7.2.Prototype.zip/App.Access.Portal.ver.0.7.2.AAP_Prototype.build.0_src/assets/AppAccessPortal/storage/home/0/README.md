# Welcome, AAP user/Nexian!

This is the AAP files partition. This is where you store your files.

Yes, it looks like:
```android
/storage/emulated/0/
```
Here, it's:
```android
/storage/home/0/
```

Root for AAP **DOES NOT EXIST!** It is non-existencial, and we as devs noticed that root is unneccessry. Your in control of your `session`. But we intentionally decided to take away access to the source code of AAP both on the documentation and here.
> Root = More conteol over the OS
Currently, we don't see the need for anyone to root AAP. There is no bloatware. No bad system apps. All optional apps are `INTERNAL`, while required ones are `SYSTEM`. **Do NOT remove system apps!!**

AAP has many versions. This is Version 1: BASIC.

Also, AAP is Downloaded from [Nexus Stack](https://botcontrol.wordpress.com)

You can use this partition for your files, just like android. System files are stored in AAP's source code, so you won't find an `{ Your OS }` folder in AAP, YET.
AAP also counts the amount of storage in itself. So, AAP clears it's cache on a daily basis.